#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_NAME_LENGTH 64

// Fonction d'aide pour afficher la bannière
void print_banner() {
    printf("\n=== Système de Gestion des Employés - ESGIS Corp ===\n");
    printf("Version: 2.3.2 - Version Sécurisée\n\n");
}

// Fonction qui affiche le flag (accès restreint)
void admin_panel() {
    char flag[60];
    FILE *f = fopen("/flag.txt", "r");
    if (f == NULL) {
        printf("[ERREUR] Fichier d'autorisations manquant.\n");
        exit(1);
    }
    if (fgets(flag, sizeof(flag), f) == NULL) {
        printf("[ERREUR] Impossible de lire le flag.\n");
        fclose(f);
        return;
    }
    printf("\n=== ACCÈS ADMINISTRATEUR AUTORISÉ ===\n");
    printf("Flag: %s", flag);
    printf("==============================\n\n");
    fclose(f);
    exit(0);
}

// Fonction sécurisée pour l'ajout d'employé
void add_employee() {
    int access_level = 1;
    char padding[16];
    char name[40];

    printf("\n[+] Ajout d'un nouvel employé\n");
    printf("Nom complet (max 100 caracteres): ");
    fflush(stdout);

    if (fgets(name, 100, stdin) == NULL) {
        printf("[ERREUR] Erreur de lecture du nom.\n");
        return;
    }

    name[strcspn(name, "\n")] = '\0';

    printf("\n[+] Employé ajouté avec succès!\n");
    printf("Nom: %s\n", name);
    printf("Niveau d'accès: %d\n", access_level);

    if (access_level == 0) {
        printf("[+] Accès administrateur détecté!\n");
        admin_panel();
    }
}

// Menu principal
void menu() {
    char input[16];
    int choice;
    
    while(1) {
        printf("\n=== MENU PRINCIPAL ===\n");
        printf("1. Ajouter un employé\n");
        printf("2. Quitter\n");
        printf("Choix: ");
        fflush(stdout);
        
        if (fgets(input, sizeof(input), stdin) == NULL) {
            clearerr(stdin);
            printf("\nErreur de lecture.\n");
            continue;
        }
        
        if (sscanf(input, "%d", &choice) != 1) {
            printf("Erreur: Veuillez entrer un nombre.\n");
            continue;
        }
        
        switch(choice) {
            case 1:
                add_employee();
                break;
            case 2:
                printf("Au revoir!\n");
                exit(0);
            default:
                printf("Option invalide.\n");
        }
    }
}

int main() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    
    print_banner();
    
    printf("AVERTISSEMENT: Ce système est la propriété exclusive d'ESGIS Corp.\n");
    printf("Toute utilisation non autorisée est strictement interdite.\n\n");
    
    menu();
    
    return 0;
}